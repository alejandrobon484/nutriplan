import MealPlanner from '@/components/MealPlanner'

export default function Home() {
  return <MealPlanner />
}
